package p1;
import java.awt.*;

public class SimpleCircle implements MatrixgameBaseEngine.Renderable {
    // x und y sind nun public, damit MatrixWire sie lesen kann
    public double x, y; 
    public double radius;
    private Color color;

    public SimpleCircle(double x, double y, double radius, Color color) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.color = color;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(this.color);
        g.fillOval((int)(x - radius), (int)(y - radius), (int)(radius * 2), (int)(radius * 2));
    }
}