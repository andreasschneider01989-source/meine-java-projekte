package p1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MATRIXGAME CORE - REINER ZOOM (Mathematische Basis)
 * * Diese Klasse ist die absolute Infrastruktur-Schicht.
 * Sie implementiert:
 * 1. Infinity Zoom (Skalierung)
 * 2. Kamera-Panning (Verschiebung im Raum)
 * 3. Dynamische Schrittweite (Geschwindigkeit passt sich dem Zoom an)
 * 4. Eine Liste für externe Module (Renderable Entities)
 */
public class MatrixgameBaseEngine extends JPanel {
    
    // Kamera-Variablen (Der Standpunkt in der Unendlichkeit)
    private double zoomFactor = 1.0;
    private double zoomCenterX = 0; 
    private double zoomCenterY = 0;
    
    // Liste für externe Objekte (z.B. deine zukünftigen Klassen)
    public final List<Renderable> entities = new ArrayList<>();

    public MatrixgameBaseEngine() {
        setBackground(Color.BLACK); // Der leere Raum ist schwarz
        setFocusable(true);
        
        // --- STEUERUNG ---
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                // Die Geschwindigkeit der Bewegung muss mit dem Zoom skalieren,
                // damit man bei hohem Zoom nicht "aus der Welt springt".
                double speed = 50.0 / zoomFactor; 
                
                switch(e.getKeyCode()) {
                    case KeyEvent.VK_UP:    zoomCenterY += speed; break;
                    case KeyEvent.VK_DOWN:  zoomCenterY -= speed; break;
                    case KeyEvent.VK_LEFT:  zoomCenterX += speed; break;
                    case KeyEvent.VK_RIGHT: zoomCenterX -= speed; break;
                    case KeyEvent.VK_PLUS:
                    case KeyEvent.VK_ADD:      zoomFactor *= 1.1; break;
                    case KeyEvent.VK_MINUS:
                    case KeyEvent.VK_SUBTRACT: zoomFactor /= 1.1; break;
                    // Reset-Taste (Nullpunkt)
                    case KeyEvent.VK_0: zoomFactor = 1.0; zoomCenterX = 0; zoomCenterY = 0; break;
                }
                repaint();
            }
        });

        // Mausrad-Support für flüssiges Hineingleiten
        addMouseWheelListener(e -> {
            if (e.getPreciseWheelRotation() < 0) zoomFactor *= 1.1;
            else zoomFactor /= 1.1;
            repaint();
        });
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // DIE RÜCKRECHNUNG: Bildschirm-Pixel -> Welt-Koordinaten
                // Wir kehren die Operationen der paintComponent um!
                double worldX = (e.getX() - getWidth() / 2.0) / zoomFactor - zoomCenterX;
                double worldY = (e.getY() - getHeight() / 2.0) / zoomFactor - zoomCenterY;

                // Prüfen, ob ein Schalter getroffen wurde
                for (Renderable ent : entities) {
                    if (ent instanceof MatrixSwitch) {
                        MatrixSwitch sw = (MatrixSwitch) ent;
                        if (sw.isClicked(worldX, worldY)) {
                            sw.isOpen = !sw.isOpen; // Zustand umschalten
                            repaint();
                        }
                    }
                }
            }
        });

        
        


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // --- DER MATHEMATISCHE ZOOM-KERN ---
        // 1. Verschiebung zur Bildschirmmitte (Zentrierung des Zooms)
        g2.translate(getWidth() / 2, getHeight() / 2);
        
        // 2. Skalierung des gesamten Raums
        g2.scale(zoomFactor, zoomFactor);
        
        // 3. Verschiebung der Welt relativ zur Kamera
        g2.translate(zoomCenterX, zoomCenterY);

        // Hier werden alle externen Objekte gezeichnet
        for (Renderable entity : entities) {
            entity.draw(g2);
        }

        // UI-Overlay (Wird nicht mitgezoomt)
        drawStaticUI(g2);
    }

    private void drawStaticUI(Graphics2D g2) {
        // Transformation kurzzeitig zurücksetzen für das UI (Fixierung am Schirm)
        java.awt.geom.AffineTransform reset = g2.getTransform();
        g2.setTransform(new java.awt.geom.AffineTransform());
        
        // Hintergrund-Panel für bessere Lesbarkeit
        g2.setColor(new Color(0, 20, 0, 180));
        g2.fillRect(10, 10, 320, 100);
        g2.setColor(new Color(0, 255, 100));
        g2.drawRect(10, 10, 320, 100);
        
        g2.setFont(new Font("Monospaced", Font.BOLD, 13));
        int x = 25;
        int y = 30;
        
        // Status & Steuerung
        g2.drawString("SYSTEM: MATRIX-CORE V3.2", x, y);
        g2.setColor(Color.WHITE);
        g2.drawString("---------------------------", x, y += 15);
        g2.drawString("MOVE:  [Pfeiltasten]", x, y += 20);
        g2.drawString("ZOOM:  [+] [-] oder Mausrad", x, y += 15);
        g2.drawString("RESET: [0] Nullpunkt", x, y += 15);
        
        // Aktueller Zoom-Wert
        g2.setColor(new Color(0, 255, 100));
        g2.drawString(String.format("ZOOM_LEVEL: %.4f", zoomFactor), x, y += 20);
        
        g2.setTransform(reset); // Zurück zur Raumzeit-Transformation für die Objekte
    }

    /**
     * Das Interface für alle Matrixgame-Module.
     */
    @FunctionalInterface
    public interface Renderable {
        void draw(Graphics2D g);
    }

    /**
     * HAUPTMETHODE: Startet das Programm.
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("Matrixgame: Pure Zoom Engine");
        // Hier wird die Variable 'engine' definiert
        MatrixgameBaseEngine engine = new MatrixgameBaseEngine();
        
        frame.add(engine);
        
        // --- SETUP DER OBJEKTE ---
        MatrixBattery batterie = new MatrixBattery(0, 0, "ENERGY");
        SimpleCircle neutralerPunkt = new SimpleCircle(200, -200, 10, Color.GRAY);

        // Leitungen erstellen
        MatrixWire leitung1 = new MatrixWire(batterie.minusPole, neutralerPunkt, false);
        MatrixWire leitung2 = new MatrixWire(neutralerPunkt, batterie.plusPole, false);

        // Zur Liste der Engine hinzufügen
        engine.entities.add(batterie);
        engine.entities.add(neutralerPunkt);
        engine.entities.add(leitung1);
        engine.entities.add(leitung2);
        
        // --- PHYSIK-LOOP (NETZWERK-LOGIK) ---
        new Timer(20, e -> {
            // 1. Alle Leitungen kurz auf 'aus' setzen
            for (Renderable ent : engine.entities) {
                if (ent instanceof MatrixWire) ((MatrixWire) ent).setPower(false);
            }

            // 2. Stromfluss propagieren (10 Iterationen für die Kette)
            List<MatrixWire> allWires = new java.util.ArrayList<>();
            for (Renderable r : engine.entities) {
                if (r instanceof MatrixWire) allWires.add((MatrixWire) r);
            }

            for (int i = 0; i < 10; i++) {
                for (MatrixWire w : allWires) {
                    w.checkConnectivity(allWires, batterie);
                }
            }
            
            engine.repaint();
        }).start();

        frame.setSize(1200, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}