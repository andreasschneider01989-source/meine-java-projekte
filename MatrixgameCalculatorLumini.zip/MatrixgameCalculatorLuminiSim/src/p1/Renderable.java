package p1;

import java.awt.Graphics2D;

public interface Renderable {
    void draw(Graphics2D g);
}