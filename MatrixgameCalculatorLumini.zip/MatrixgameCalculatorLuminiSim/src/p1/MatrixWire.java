package p1;

import java.awt.*;
import java.awt.geom.Ellipse2D;
// WICHTIG: Sicherstellen, dass java.util.List importiert ist, nicht java.awt.List
import java.util.List; 

public class MatrixWire implements MatrixgameBaseEngine.Renderable {
    public SimpleCircle startNode;
    public SimpleCircle endNode;
    public boolean hasPower = false;
    private double electronFrame = 0;

    public MatrixWire(SimpleCircle a, SimpleCircle b, boolean power) {
        this.startNode = a;
        this.endNode = b;
        this.hasPower = power;
    }

    /**
     * Die Logik-Propagierung: Prüft, ob diese Leitung Strom von der Batterie 
     * oder von einer benachbarten, geladenen Leitung erhält.
     */
    public void checkConnectivity(List<MatrixWire> allWires, MatrixBattery bat) {
        // 1. Direktkontakt mit dem Pluspol der Batterie?
        if (startNode == bat.plusPole || endNode == bat.plusPole) {
            this.hasPower = true;
            return; 
        }

        // 2. Kontakt mit einer anderen Leitung, die bereits Strom hat?
        for (MatrixWire other : allWires) {
            if (other != this && other.hasPower) {
                // Wenn sich die Leitungen an einem der Knoten berühren
                if (this.startNode == other.startNode || this.startNode == other.endNode ||
                    this.endNode == other.startNode || this.endNode == other.endNode) {
                    this.hasPower = true;
                    return;
                }
            }
        }
    }

    public void setPower(boolean state) {
        this.hasPower = state;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setStroke(new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // Farbe: Gelb wenn Strom fließt, Braun wenn kein Strom
        g.setColor(hasPower ? Color.YELLOW : new Color(139, 69, 19));
        g.drawLine((int)startNode.x, (int)startNode.y, (int)endNode.x, (int)endNode.y);

        // Optional: Kleine fließende Elektronen-Animation
        if (hasPower) {
            electronFrame += 0.5;
            drawElectrons(g);
        }
    }

    private void drawElectrons(Graphics2D g) {
        g.setColor(Color.WHITE);
        double dx = endNode.x - startNode.x;
        double dy = endNode.y - startNode.y;
        double dist = Math.sqrt(dx*dx + dy*dy);
        for (double d = (electronFrame % 20); d < dist; d += 20) {
            double r = d / dist;
            g.fill(new Ellipse2D.Double(startNode.x + dx*r - 2, startNode.y + dy*r - 2, 4, 4));
        }
    }
}