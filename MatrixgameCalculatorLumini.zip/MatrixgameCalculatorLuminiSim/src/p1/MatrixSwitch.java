package p1;

import java.awt.*;

public class MatrixSwitch implements MatrixgameBaseEngine.Renderable {
    public SimpleCircle inNode;
    public SimpleCircle outNode;
    public boolean isOpen = true; // Offen = kein Stromfluss
    public boolean hasPower = false; // Wird von der Engine berechnet

    public MatrixSwitch(double x, double y) {
        // Der Schalter hat zwei eigene kleine Pole
        this.inNode = new SimpleCircle(x - 20, y, 8, Color.WHITE);
        this.outNode = new SimpleCircle(x + 20, y, 8, Color.WHITE);
    }

    // Prüft, ob ein Mausklick (im Welt-System) diesen Schalter getroffen hat
    public boolean isClicked(double worldX, double worldY) {
        double centerX = (inNode.x + outNode.x) / 2;
        double centerY = (inNode.y + outNode.y) / 2;
        double dist = Math.sqrt(Math.pow(worldX - centerX, 2) + Math.pow(worldY - centerY, 2));
        return dist < 25; // Klick-Radius
    }

    @Override
    public void draw(Graphics2D g) {
        // Gehäuse
        g.setColor(Color.DARK_GRAY);
        g.drawRect((int)inNode.x, (int)inNode.y - 15, 40, 30);

        // Der Hebel
        g.setStroke(new BasicStroke(3));
        g.setColor(isOpen ? Color.RED : Color.GREEN);
        
        if (isOpen) {
            // Hebel steht nach oben (offen)
            g.drawLine((int)inNode.x, (int)inNode.y, (int)inNode.x + 20, (int)inNode.y - 20);
        } else {
            // Hebel verbindet beide Punkte (geschlossen)
            g.drawLine((int)inNode.x, (int)inNode.y, (int)outNode.x, (int)outNode.y);
        }

        inNode.draw(g);
        outNode.draw(g);
    }
}