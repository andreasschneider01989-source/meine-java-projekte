package p1;

import java.awt.*;

/**
 * MODUL: MatrixBattery
 * Eine Stromquelle mit zwei Polen. 
 * Dient als Start- und Endpunkt für die Stromkreislogik.
 */
public class MatrixBattery implements MatrixgameBaseEngine.Renderable {
    public SimpleCircle plusPole;
    public SimpleCircle minusPole;
    private String label;

    public MatrixBattery(double x, double y, String label) {
        this.label = label;
        // Wir platzieren die Pole relativ zum Gehäuse der Batterie
        this.minusPole = new SimpleCircle(x - 40, y, 10, Color.BLUE);
        this.plusPole  = new SimpleCircle(x + 40, y, 10, Color.RED);
    }

    @Override
    public void draw(Graphics2D g) {
        // 1. Das Gehäuse der Batterie zeichnen
        g.setColor(new Color(60, 60, 60));
        double width = 100, height = 50;
        // Zentriere das Rechteck um die Pole
        g.fillRoundRect((int)(minusPole.x - 20), (int)(minusPole.y - 25), (int)width, (int)height, 10, 10);
        
        // 2. Beschriftung
        g.setColor(Color.WHITE);
        g.setFont(new Font("Monospaced", Font.BOLD, 12));
        g.drawString(label, (int)minusPole.x - 10, (int)minusPole.y + 5);
        g.drawString("-", (int)minusPole.x - 5, (int)minusPole.y - 15);
        g.drawString("+", (int)plusPole.x - 5, (int)plusPole.y - 15);

        // 3. Die Pole selbst zeichnen (da sie Renderables sind, rufen wir ihre draw-Methode auf)
        minusPole.draw(g);
        plusPole.draw(g);
    }
}